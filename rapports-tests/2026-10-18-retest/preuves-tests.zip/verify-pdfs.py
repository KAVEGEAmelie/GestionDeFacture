import json
import pathlib
import re
import subprocess
import unicodedata

root = pathlib.Path('/tmp/gestion-facture-tests')
report = json.loads((root / 'pdf-results.json').read_text())
def normalize(value):
    value = ''.join(c for c in unicodedata.normalize('NFKD', value) if not unicodedata.combining(c))
    return re.sub(r'\s+', ' ', value).casefold()

for result in report['results']:
    if result['status'] != 'PASS' or 'file' not in result:
        continue
    text = subprocess.check_output(['pdftotext', '-layout', result['file'], '-'], text=True)
    pathlib.Path(result['file']).with_suffix('.txt').write_text(text)
    missing = [s for s in result['checks'] if normalize(s) not in normalize(text)]
    unexpected = [s for s in result.get('excluded', []) if normalize(s) in normalize(text)]
    result['textChecksPassed'] = not (missing or unexpected)
    result['missingText'] = missing
    result['unexpectedText'] = unexpected
    if missing or unexpected:
        result['status'] = 'FAIL'
    print(result['status'], pathlib.Path(result['file']).name, 'contenu texte', missing, unexpected)

(root / 'pdf-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
raise SystemExit(int(any(r['status'] == 'FAIL' for r in report['results'])))
