const fs=require('fs');const path=require('path');const vm=require('vm');const assert=require('assert/strict');const h=require('./harness.cjs');
const results=[];
async function main(){
  const a=h.createApp();const f=h.fixture(a);const p=h.proforma(a,f);const inv=a.call('factures:createFromProforma',p.id,'2026-10-18');const b=a.call('bordereaux:createFromFacture',inv.id);
  a.call('factureSituations:create',inv.id,95);a.call('factureSituations:create',inv.id,5);const [s95,s5]=a.call('factureSituations:getByFacture',inv.id);
  const params=a.call('parametres:getAll');const logo=fs.readFileSync(path.join(h.root,'src/assets/logo.png'));
  const logoData={dataUrl:'data:image/png;base64,'+logo.toString('base64'),width:logo.readUInt32BE(16),height:logo.readUInt32BE(20)};
  const code=h.req('@babel/core').transformSync(fs.readFileSync(path.join(h.root,'src/utils/pdfGenerator.js'),'utf8'),{babelrc:false,configFile:false,plugins:[h.req.resolve('@babel/plugin-transform-modules-commonjs')]}).code;
  const module={exports:{}};vm.runInNewContext(code,{module,exports:module.exports,console,Buffer,require:name=>name==='./logo'?{getLogoDataURL:async()=>logoData}:h.req(name)});
  const pdf=module.exports;const out='/tmp/gestion-facture-tests/pdfs';fs.mkdirSync(out,{recursive:true});
  async function test(name,fn,checks=[],baseline=true,excluded=[]){
    try{const doc=await fn();const bytes=Buffer.from(doc.output('arraybuffer'));assert.equal(bytes.subarray(0,5).toString(),'%PDF-');assert.ok(bytes.length>1000);const pages=doc.getNumberOfPages();assert.ok(pages>0);
      const file=path.join(out,name+'.pdf');fs.writeFileSync(file,bytes);results.push({name,status:'PASS',pages,bytes:bytes.length,file,checks,excluded,baseline});console.log('PASS PDF',name,pages,'page(s)');
    }catch(e){results.push({name,status:'FAIL',error:e.message,baseline});console.log('FAIL PDF',name,e.message);}
  }
  const fullP=a.call('proformas:getById',p.id),fullInv=a.call('factures:getById',inv.id);
  await test('proforma',()=>pdf.generateProformaPDF(fullP,params),['129 800','Description détaillée']);
  await test('facture',()=>pdf.generateFacturePDF(fullInv,params),['129 800']);
  await test('situation-95',()=>pdf.generateFactureSituationPDF(s95,fullInv,params,{estPremiere:true,cumulTaux:95,cumulTtc:s95.montant_ttc}),['95','123 310']);
  await test('situation-5',()=>pdf.generateFactureSituationPDF(s5,fullInv,params,{estPremiere:false,cumulTaux:100,cumulTtc:129800}),['6 490']);
  await test('bordereau',()=>pdf.generateBordereauPDF(a.call('bordereaux:getById',b.id),params),['Routeur test']);
  await test('attestation',()=>pdf.generateAttestationPDF({numero:'ASF-TEST',date:'2026-10-18',client_nom:'Client de test',travaux:['Installation réseau','Validation des tests'],intro:'Nous certifions la réalisation des travaux.',conformite:'Travaux réceptionnés.'},params),['Installation réseau']);
  const fit={numero:'2026/00017-ITS',date:'2026-10-18',client_nom:'Client de test',intervenant:'Technicien test',categorie:['Réseau informatique'],description_probleme:'Réseau indisponible',travaux_realises:'Remplacement du câble et tests',diagnostic:'Câble défectueux',statut_final:'Résolu',materiels:'Câble Ethernet'};
  await test('intervention-simplifiee',()=>pdf.generateInterventionPDF(fit,params),['Réseau indisponible']);
  await test('intervention-v11',()=>pdf.generateInterventionV11PDF({...fit,materiels:[{designation:'Câble',qte:'1',etat:'Neuf',ref:'CAT6',garantie:'1 an'}],nature:['Maintenance'],tests:['Ping'],backup_before:'Non nécessaire'},params),['Réseau indisponible']);
  await test('rapport-technique',()=>pdf.generateRapportPDF({numero:'R-TEST',date:'2026-10-18',titre:'Rapport technique test',client_nom:'Client de test',sections:[{titre:'Diagnostic',contenu:'Réseau rétabli.\n- Câble remplacé\n- Test de connexion validé'}]},params),['Réseau rétabli']);
  await test('rapport-long',()=>pdf.generateRapportPDF({numero:'R-LONG',date:'2026-10-18',titre:'Rapport long test',sections:Array.from({length:20},(_,i)=>({titre:'Section '+(i+1),contenu:'Texte de vérification du rapport et de la pagination. '.repeat(60)}))},params),['Section 20']);
  const longLines=Array.from({length:80},(_,i)=>({...fullP.lignes[0],designation:'Produit long '+(i+1),description:'Description détaillée sur plusieurs lignes. '.repeat(3)}));
  await test('proforma-longue',()=>pdf.generateProformaPDF({...fullP,lignes:longLines},params),['Produit long 80']);
  await test('tva',()=>pdf.generateTvaPDF({titre:'TVA test',lignes:[{numero:fullInv.numero,client:fullInv.client_nom,date:'18/10/2026',total_ttc:129800,tva:19800}],totalTtc:129800,totalTva:19800},params),['9 900']);
  const lot={id:1,numero:'VT-0001',date:'2026-10-18',nb_factures:1,total_tva:19800,total_du:9900,quittance:9900,paye:4900,reste:5000,solde:false,note:'Test détail de versement',
    factures:[{id:inv.id,numero:fullInv.numero,client_nom:'Client de test',tva:19800}],
    paiements:[{id:1,date:'2026-10-17',montant:2000,quittance:'Q-001',mode:'Espèces',note:'Premier paiement'},{id:2,date:'2026-10-18',montant:2900,quittance:'Q-002',mode:'Virement',note:'Deuxième paiement'}]};
  await test('tva-versements',()=>pdf.generateTvaVersementsPDF({lignes:[lot],totalTva:19800,totalDu:9900,totalQuittance:9900,totalPaye:4900,totalReste:5000},params),['VT-0001']);
  await test('otr-detail-versement',()=>pdf.generateTvaVersementDetailPDF(lot,params),['VT-0001','Q-001','Q-002','5 000','Relevé interne'],false);
  await test('otr-detail-paiement',()=>pdf.generateTvaVersementDetailPDF(lot,params,2),['VT-0001','Q-002','2 900','Paiement sélectionné'],false,['Q-001']);
  await test('otr-detail-vide',()=>pdf.generateTvaVersementDetailPDF({numero:'VT-VIDE',date:'2026-10-18',total_du:0,paye:0,reste:0,factures:[],paiements:[]},params),['Aucune facture rattachée','Aucun paiement enregistré'],false);
  const huge={...lot,numero:'VT-LONG',factures:Array.from({length:100},(_,i)=>({numero:'FACTURE-'+(i+1),client_nom:'Client de test '+i,tva:19800})),paiements:Array.from({length:100},(_,i)=>({id:i+1,date:'2026-10-18',montant:100,quittance:'QUITTANCE-'+(i+1),mode:'Virement',note:'Historique du paiement'}))};
  await test('otr-detail-long',()=>pdf.generateTvaVersementDetailPDF(huge,params),['FACTURE-100','QUITTANCE-100'],false);
  try{await assert.rejects(()=>pdf.generateTvaVersementDetailPDF(lot,params,999),/Paiement introuvable/);results.push({name:'otr-paiement-inexistant-refuse',status:'PASS',baseline:false});console.log('PASS paiement inexistant refusé');}
  catch(e){results.push({name:'otr-paiement-inexistant-refuse',status:'FAIL',error:e.message,baseline:false});}
  fs.writeFileSync('/tmp/gestion-facture-tests/pdf-results.json',JSON.stringify({results,limitation:'Générateurs réels, lecture directe du logo PNG au lieu du chargement navigateur.'},null,2));
  a.close();console.log('RESULT',JSON.stringify({pass:results.filter(r=>r.status==='PASS').length,fail:results.filter(r=>r.status==='FAIL').length}));if(results.some(r=>r.status==='FAIL'))process.exitCode=1;
}
main().catch(e=>{console.error(e);process.exitCode=2});
