const fs=require('fs'); const path=require('path'); const assert=require('assert/strict');
const {TextEncoder,TextDecoder}=require('util'); const h=require('./harness.cjs');
const {JSDOM,VirtualConsole}=h.req('jsdom'); const results=[];
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,ms=12000){const start=Date.now();while(!fn()){if(Date.now()-start>ms)throw Error('Délai dépassé');await delay(25);}}
async function main(){
  const a=h.createApp(); const f=h.fixture(a); const p=h.proforma(a,f); const inv=a.call('factures:createFromProforma',p.id,'2026-10-18');
  a.call('bordereaux:createFromFacture',inv.id);
  a.call('rapports:create',{date:'2026-10-18',titre:'Rapport test',client_id:f.client,sections:[{titre:'Diagnostic',contenu:'Réseau rétabli'}]});
  a.call('attestations:create',{date:'2026-10-18',client_nom:'Client de test',travaux:['Installation']});
  a.call('interventions:create',{date:'2026-10-18',intervenant:'Technicien test',client_nom:'Client de test',details:{modele:'simplifie'}});
  a.call('factures:markPaid',inv.id,'2026-10-17'); const lot=a.call('tva:verser',[inv.id]);
  a.call('tva:ajouterPaiement',lot.id,{montant:4900,date:'2026-10-18',quittance:'Q-UI-001',mode:'Espèces'});
  a.handlers.set('license:getStatus',()=>({blocked:false,activated:false,trialDays:18,daysLeft:18,machineId:'TEST-TEST-TEST-TEST'}));
  const errors=[]; const vc=new VirtualConsole(); vc.on('jsdomError',e=>errors.push(e.message)); vc.on('error',(...args)=>errors.push(args.map(String).join(' ')));
  const printWindows=[]; const blobs=[];
  const dom=await JSDOM.fromFile('/tmp/gestion-facture-corrections-build/index.html',{
    runScripts:'dangerously',resources:'usable',pretendToBeVisual:true,virtualConsole:vc,
    beforeParse(win){
      win.electronAPI=a.api;win.TextEncoder=TextEncoder;win.TextDecoder=TextDecoder;
      const data=new Map(); Object.defineProperty(win,'localStorage',{value:{getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,String(v)),removeItem:k=>data.delete(k)}});
      win.addEventListener('unhandledrejection',e=>errors.push(String(e.reason)));
      win.Image=class {set src(v){setTimeout(()=>this.onerror?.(),0)}};
      win.URL.createObjectURL=blob=>{blobs.push(blob);return 'blob:test-'+blobs.length;};
      win.URL.revokeObjectURL=()=>{};
      win.open=()=>{const p={location:{href:''},closed:false,close(){this.closed=true;}};printWindows.push(p);return p;};
    }
  });
  const w=dom.window,d=w.document;
  async function test(name,fn,baseline=true){try{await fn();results.push({name,status:'PASS',baseline});console.log('PASS',name);}catch(e){results.push({name,status:'FAIL',error:e.message,baseline});console.log('FAIL',name,e.message);}}
  async function route(name){w.location.hash='#/'+name;await waitFor(()=>d.querySelector(`a[href="#/${name}"].active`));await delay(100);}
  const button=(text,scope=d)=>[...scope.querySelectorAll('button')].find(b=>b.textContent.trim()===text);
  async function setInput(input,value){assert.ok(input,'Champ introuvable');Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype,'value').set.call(input,value);input.dispatchEvent(new w.Event('input',{bubbles:true}));await delay(35);}
  async function select(input,value){Object.getOwnPropertyDescriptor(w.HTMLSelectElement.prototype,'value').set.call(input,String(value));input.dispatchEvent(new w.Event('change',{bubbles:true}));await delay(35);}
  await waitFor(()=>d.querySelector('h1'));
  for(const name of ['dashboard','clients','produits','proformas','factures','bordereaux','tva','rapports','attestation-service-fait','interventions','parametres']){
    await test('Écran '+name,async()=>{const before=errors.length;await route(name);assert.ok(d.querySelector('main').textContent.trim().length>20);assert.equal(errors.length,before,errors.slice(before).join('\n'));fs.writeFileSync(path.join(a.dir,name+'.html'),d.documentElement.outerHTML);});
  }
  for(const [name,text]of [['clients','Nouveau client'],['produits','Nouveau produit'],['proformas','Nouvelle proforma'],['factures','Convertir'],['bordereaux','Nouveau bordereau'],['rapports','Nouveau rapport'],['attestation-service-fait','Nouvelle attestation'],['interventions','Nouvelle fiche']]){
    await test('Ouverture/fermeture formulaire '+name,async()=>{await route(name);const btn=[...d.querySelectorAll('main button')].find(b=>b.textContent.toLowerCase().includes(text.toLowerCase()));assert.ok(btn,`Bouton ${text} introuvable`);btn.click();await delay(50);assert.ok(d.querySelector('.modal-overlay'));assert.ok(d.querySelector('.modal-body').textContent.length>10);d.querySelector('.modal-close').click();await delay(30);assert.equal(d.querySelector('.modal-overlay'),null);});
  }
  for(const [name,label,field,value,table]of [['clients','Nouveau client','nom','Client créé depuis le formulaire','clients'],['produits','Nouveau produit','designation','Produit créé depuis le formulaire','produits']]){
    await test('Saisie et enregistrement via formulaire '+name,async()=>{
      await route(name);button(label,d.querySelector('main')).click();await delay(50);await setInput(d.querySelector(`.modal-body input[name="${field}"]`),value);
      const price=d.querySelector('.modal-body input[name="prix_unitaire"]');if(price)await setInput(price,'12500');
      d.querySelector('.modal-body form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await waitFor(()=>!d.querySelector('.modal-overlay'));
      assert.ok(a.db.prepare(`SELECT 1 FROM ${table} WHERE ${field} = ?`).get(value));assert.ok(d.querySelector('main').textContent.includes(value));
    });
  }
  await route('proformas');button('Nouvelle proforma',d.querySelector('main')).click();await delay(60);
  button('Ajouter une section').click();await delay(35);button('Ajouter une section').click();await delay(35);
  const sectionInputs=()=>[...d.querySelectorAll('.ligne-table tbody tr')].filter(r=>r.querySelector('button[title="Ajouter une ligne à cette section"]')).map(r=>r.querySelector('input'));
  const sectionRows=()=>[...d.querySelectorAll('.ligne-table tbody tr')].filter(r=>r.querySelector('button[title="Ajouter une ligne à cette section"]'));
  await setInput(sectionInputs()[0],'Section A');await setInput(sectionInputs()[1],'Section B');
  async function addLine(label){
    const panel=d.querySelector('.ligne-form-panel');const group=[...panel.querySelectorAll('.form-group')].find(g=>g.querySelector('label')?.textContent==='Désignation');
    await setInput(group.querySelector('input'),label);button('Ajouter',panel).click();await delay(45);assert.equal(d.querySelector('.ligne-form-panel'),null);
  }
  await test('Ajout ciblé dans la première section',async()=>{
    sectionRows()[0].querySelector('button[title="Ajouter une ligne à cette section"]').click();await delay(40);
    assert.equal(d.querySelector('.ligne-form-panel select').value,'0');await addLine('Ligne section A');
    const rows=[...d.querySelectorAll('.ligne-table tbody tr')];assert.equal(rows.length,3);assert.ok(rows[1].querySelector('input[value="Ligne section A"]'));assert.ok(rows[2].querySelector('input[value="Section B"]'));
  },false);
  await test('Ajout sans section avant les sections existantes',async()=>{
    button('Ajouter une ligne').click();await delay(40);await select(d.querySelector('.ligne-form-panel select'),-1);await addLine('Ligne sans section');
    assert.ok(d.querySelector('.ligne-table tbody tr:first-child input[value="Ligne sans section"]'));
  },false);
  await test('Ajout général sélectionne la dernière section',async()=>{
    button('Ajouter une ligne').click();await delay(40);const s=d.querySelector('.ligne-form-panel select');assert.equal(s.selectedOptions[0].textContent,'Section B');
    await addLine('Ligne section B');assert.ok(d.querySelector('.ligne-table tbody tr:last-child input[value="Ligne section B"]'));
  },false);
  d.querySelector('.modal-close').click();await delay(30);await route('tva');
  await test('Impression du détail de versement OTR',async()=>{
    [...d.querySelectorAll('main button')].find(b=>b.textContent.includes('Versements OTR')).click();await delay(80);
    const btn=d.querySelector('button[title="Imprimer ce versement et ses détails"]');assert.ok(btn);const old=printWindows.length;btn.click();
    await waitFor(()=>printWindows.length===old+1&&printWindows[old].location.href.startsWith('blob:'));assert.ok(blobs.at(-1).size>1000);
  },false);
  await test('Impression du paiement individuel OTR',async()=>{
    const row=[...d.querySelectorAll('tr')].find(r=>r.textContent.includes('VT-0001')&&r.querySelector('button[title="Imprimer ce versement et ses détails"]'));
    const btn=[...row.querySelectorAll('button')].find(b=>b.getAttribute('title')?.match(/détail|Dépli|Repli|Afficher|Masquer/i)&&!b.title.startsWith('Imprimer'));
    assert.ok(btn,'Bouton de détail introuvable');btn.click();await delay(60);
    const print=d.querySelector('button[title="Imprimer ce paiement"]');assert.ok(print);const old=printWindows.length;print.click();
    await waitFor(()=>printWindows.length===old+1&&printWindows[old].location.href.startsWith('blob:'));assert.ok(blobs.at(-1).size>1000);
  },false);
  await test('Impression OTR : message si fenêtre bloquée',async()=>{
    const previous=w.open;w.open=()=>null;try{d.querySelector('button[title="Imprimer ce versement et ses détails"]').click();await waitFor(()=>d.body.textContent.includes('Autorisez les fenêtres contextuelles'));}finally{w.open=previous;}
  },false);
  const controlled=h.facture(a,f);
  const s95=a.call('factureSituations:create',controlled.id,95),s5=a.call('factureSituations:create',controlled.id,5);
  a.call('factureSituations:markPaid',s95.id,'2026-10-10');a.call('factureSituations:markPaid',s5.id,'2026-10-15');
  const invoiceRow=()=>[...d.querySelectorAll('main tbody tr')].find(row=>row.cells[1]?.textContent.trim()===controlled.numero);
  const situationRow=id=>[...d.querySelectorAll('.modal-body tbody tr')].find(row=>row.cells[0]?.textContent.includes(id));
  const waitConfirm=()=>waitFor(()=>d.querySelector('.confirm-dialog'));
  await test('Facture payée : accès aux situations conservé',async()=>{
    await route('factures');
    const row=invoiceRow();assert.ok(row);const open=row.querySelector('button[title="Facturation par situation (paiement partiel en %)"]');assert.ok(open);open.click();
    await waitFor(()=>d.querySelector('.modal-header')?.textContent.includes(controlled.numero));assert.equal(d.querySelectorAll('.modal-body tbody tr').length,2);
  },false);
  await test('Interface : suppression de tranche payée refusée',async()=>{
    situationRow(s5.numero).querySelector('button[title="Supprimer"]').click();
    await waitFor(()=>d.body.textContent.includes("Annulez d'abord le paiement de cette situation"));
    assert.equal(d.querySelector('.confirm-dialog'),null);assert.equal(a.call('factureSituations:getByFacture',controlled.id).length,2);
  },false);
  await test('Interface : annulation du paiement exige confirmation',async()=>{
    situationRow(s5.numero).querySelector('button[title="Annuler le paiement"]').click();await waitConfirm();
    d.querySelector('.confirm-cancel').click();await delay(60);
    assert.equal(a.call('factures:getById',controlled.id).statut_paiement,'payee');
  },false);
  await test('Interface : annulation du solde actualise le statut parent',async()=>{
    situationRow(s5.numero).querySelector('button[title="Annuler le paiement"]').click();await waitConfirm();d.querySelector('.confirm-danger').click();
    await waitFor(()=>a.call('factures:getById',controlled.id).statut_paiement==='non_payee');
    await waitFor(()=>invoiceRow().textContent.includes('Non payée'));assert.ok(situationRow(s5.numero).textContent.includes('Non payée'));
  },false);
  await test('Interface : suppression après annulation actualise les tranches',async()=>{
    situationRow(s5.numero).querySelector('button[title="Supprimer"]').click();await waitConfirm();d.querySelector('.confirm-danger').click();
    await waitFor(()=>d.querySelectorAll('.modal-body tbody tr').length===1);
    assert.equal(a.call('factureSituations:getByFacture',controlled.id).length,1);
    assert.equal(a.call('factures:getById',controlled.id).statut_paiement,'non_payee');
  },false);
  await test('Interface : paiement protégé par un lot OTR en cours',async()=>{
    a.call('tva:verser',[controlled.id]);
    situationRow(s95.numero).querySelector('button[title="Annuler le paiement"]').click();await waitConfirm();d.querySelector('.confirm-danger').click();
    await waitFor(()=>d.body.textContent.includes('Cette facture est liée à une TVA versée ou à un lot OTR'));
    assert.equal(a.call('factureSituations:getByFacture',controlled.id)[0].statut_paiement,'payee');
  },false);
  fs.writeFileSync('/tmp/gestion-facture-tests/ui-corrections-results.json',JSON.stringify({results,errors,base:a.dir,limitation:'Build réel dans jsdom, vrai IPC et SQLite temporaire, logo navigateur absent et fenêtre d’impression simulée ; pas de validation graphique Electron.'},null,2));
  w.close();a.close();console.log('RESULT',JSON.stringify({pass:results.filter(r=>r.status==='PASS').length,fail:results.filter(r=>r.status==='FAIL').length,errors}));
  if(results.some(r=>r.status==='FAIL'))process.exitCode=1;
}
main().catch(e=>{console.error(e);process.exitCode=2});
